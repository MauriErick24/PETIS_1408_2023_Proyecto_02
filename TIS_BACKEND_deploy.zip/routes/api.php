<?php

use App\Http\Controllers\ActividadController;
use App\Http\Controllers\AficheController;
use App\Http\Controllers\AuspiciadorController;
use App\Http\Controllers\ComunicadoController;
use App\Http\Controllers\EventoController;
use App\Http\Controllers\OrganizadorController;
use App\Http\Controllers\PremioController;
use App\Http\Controllers\RequisitoController;
use App\Http\Controllers\tipoEventoController;
use App\Http\Controllers\UserController;
use App\Models\Actividad;
use App\Models\Auspiciador;
use App\Models\Evento;
use App\Models\Premio;
use App\Models\Requisito;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('register', [UserController::class, 'register']);
Route::post('login', [UserController::class, 'login']);

Route::group(['middleware' => ["auth:sanctum"]], function () {
    Route::get('showUser', [UserController::class, 'showUser']);
    Route::get('logout', [UserController::class, 'logout']);
});

Route::resource('evento', EventoController::class);
Route::resource('tipoEvento', tipoEventoController::class);
Route::resource('auspiciadores', AuspiciadorController::class);
Route::resource('organizadores', OrganizadorController::class);
Route::resource('premios', PremioController::class);
Route::resource('requisitos', RequisitoController::class);
Route::resource('afiches', AficheController::class);
Route::resource('actividades', ActividadController::class);
Route::resource('comunicados', ComunicadoController::class);

Route::get('mostrarAfiches', [EventoController::class, 'mostrarAfiches']);
Route::post('cambiarImagen', [EventoController::class, 'cambiarImg']);
Route::get('pasados', [EventoController::class, 'pasados']);
Route::get('presentes', [EventoController::class, 'presentes']);
Route::get('futuros', [EventoController::class, 'futuros']);
Route::get('asignarComunicado', [ComunicadoController::class, 'cantDatos']);
Route::post('asignarAuspiciador', [AuspiciadorController::class, 'asignarAuspiciador']);
Route::post('asignarOrganizador', [OrganizadorController::class, 'agregarOrganizador']);
Route::get('mostrarPremios', [PremioController::class, 'cantDatos']);
Route::post('quitarPremios', [PremioController::class, 'desasignarPremio']);
